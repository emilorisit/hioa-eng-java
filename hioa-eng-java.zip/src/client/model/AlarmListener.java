package client.model;

public interface AlarmListener {
	public void alarmEventOccured(AlarmEvent ae);

}
