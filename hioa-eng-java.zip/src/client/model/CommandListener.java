package client.model;

public interface CommandListener {
	public void commandEventOccured(CommandEvent ce);

}
