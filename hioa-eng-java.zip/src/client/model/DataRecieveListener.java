package client.model;

public interface DataRecieveListener {
	public void dataRecieveEventOccured(DataRecieveEvent ev);
}
