package client.model;

public interface LoginListener {
	public void loginEventOccured(LoginEvent ev);

}
