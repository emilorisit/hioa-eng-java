package client.model;

public interface LogoutListener {
	public void logoutOccured(LogoutEvent lev);

}
