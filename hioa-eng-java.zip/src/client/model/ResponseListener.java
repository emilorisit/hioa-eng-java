package client.model;

public interface ResponseListener {
	public void responseOccured(ResponseEvent re);
}
