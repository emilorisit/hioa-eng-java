package server.model;

public interface LoginListener {
	public void loginEventOccured(LoginEvent le);

}
