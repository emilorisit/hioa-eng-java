package server.model;

public interface TankListener {
	public void tankEventOccured(TankEvent ev);
}
